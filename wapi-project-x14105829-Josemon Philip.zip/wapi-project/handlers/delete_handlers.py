from google.appengine.api import users
from google.appengine.ext import ndb
from models import Manufacturer, Product,Order,Order_Item
import utils
import json
import webapp2

class delete_manufactureJson(webapp2.RequestHandler):

	def delete(self,id):
		query_results = Manufacturer.query(Manufacturer.id==id).fetch()
		if len(query_results) == 0:
			self.error(404)
		else:
			#Get the key of the object and deltet it from the key-value data store
			manufacture = query_results[0]
			key = manufacture.key
			key.delete()
			#return a message to the client
			data = {}
			data['message'] = 'Deleted Manufacturer:'+id
			json_response = json.dumps(data)
			self.response.headers['Content-Type'] = 'text/x-json'
			self.response.write(json_response)


class delete_productJson(webapp2.RequestHandler):

	def delete(self,id):
		query_results = Product.query(Product.id==id).fetch()
		if len(query_results) == 0:
			self.error(404)
		else:
			#Get the key of the object and deltet it from the key-value data store
			product = query_results[0]
			key = product.key
			key.delete()
			#return a message to the client
			data = {}
			data['message'] = 'Deleted Product:'+id
			json_response = json.dumps(data)
			self.response.headers['Content-Type'] = 'text/x-json'
			self.response.write(json_response)
			
class delete_cartItemJson(webapp2.RequestHandler):
	def delete(self,id):
		cartItem_key = ndb.Key(urlsafe=id)
		cartItem_key.delete();
		data = {}
		data['message'] = 'Item Deleted'
		json_response = json.dumps(data)
		self.response.headers['Content-Type'] = 'text/x-json'
		self.response.write(json_response)

class delete_orderJson(webapp2.RequestHandler):
	def delete(self,id):
		user = users.get_current_user()
		query_results = Order.query(ndb.AND(Order.id==int(id),Order.user_id==user.user_id())).fetch()
		ord=query_results[0]
		key=ord.key
		key.delete()
		orderitem_results = Order_Item.query(ndb.AND(Order_Item.order_id==int(id),Order_Item.user_id==user.user_id())).fetch(keys_only=True)
		ndb.delete_multi(orderitem_results)
		data = {}
		data['message'] = 'Item Deleted'
		json_response = json.dumps(data)
		self.response.headers['Content-Type'] = 'text/x-json'
		self.response.write(json_response)