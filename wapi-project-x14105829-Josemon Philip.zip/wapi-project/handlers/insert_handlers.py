from google.appengine.api import users
from google.appengine.ext import ndb
from models import Manufacturer, Product,User,Cart_Item,Order,Order_Item
import utils
import json
import webapp2
import logging

class AddUser(webapp2.RequestHandler):
	def post(self):
		user = users.get_current_user()
		query_results = User.query(User.id==user.user_id()).fetch()
		if len(query_results) == 0:
			new_user = User()
			new_user.id = user.user_id()
		else:
			new_user = query_results[0]

		#id=user.email().lower(),
		new_user.user_name=self.request.get('user_name')
		new_user.user_address=self.request.get('user_address')
		new_user.put()
		self.redirect("/")
	



class AddManufactureAction(webapp2.RequestHandler):

	def post(self):
		#user = users.get_current_user()
		urlsafe_entity_key = self.request.get('manufacture_entity_key')
		if len(urlsafe_entity_key) > 0:
			# Edit
			manufacture_key = ndb.Key(urlsafe=urlsafe_entity_key)
			manufacture = manufacture_key.get()
		else:
			# Add
			manufacture = Manufacturer()
		manufacture.business_name = self.request.get('business_name')
		manufacture.email_address = self.request.get('email_address')
		manufacture.url_address = self.request.get('url_address')
		manufacture.phone_number = self.request.get('phone_number')
					
		manufacture.put()
		self.redirect("/manufacture")

		
		
class AddManufactureJson(webapp2.RequestHandler):
	def post(self):
		manuJson = json.loads(self.request.body)
		#id=self.request.get['id']
		#urlsafe_entity_key = self.request.get('manufacture_entity_key')
		query_results = Manufacturer.query(Manufacturer.id==manuJson["id"]).fetch()
		
		if len(query_results) == 0:
			# Edit
			#manufacture_key = ndb.Key(urlsafe=urlsafe_entity_key)
			#manufacture = manufacture_key.get()
			
			manufacture = Manufacturer()
		else:
			# Add
			manufacture = query_results[0];
			
		manufacture.id = manuJson["id"]
		manufacture.business_name = manuJson["business_name"]
		manufacture.email_address = manuJson["email_address"]
		manufacture.url_address = manuJson["url_address"]
		manufacture.phone_number = manuJson["phone_number"]
					
		manufacture.put()
		data = {}
		data['message'] = 'Updated Manufacturer (PUT):'+manuJson["id"]
		json_response = json.dumps(data)
		self.response.headers['Content-Type'] = 'text/x-json'
		self.response.write(json_response)


class AddProductsAction(webapp2.RequestHandler):

	def post(self):
		urlsafe_entity_key = self.request.get('product_entity_key')
		manufacturer_key = ndb.Key(urlsafe=self.request.get('manufacturer_key'))
		if len(urlsafe_entity_key) > 0:
			product_key=ndb.Key(urlsafe=urlsafe_entity_key)
			product=product_key.get()
		else:
			product=Product()
		product.parent=manufacturer_key
		product.product_name=self.request.get('product_name')
		product.unit_cost=float(self.request.get('unit_cost'))
		product.number_in_stock=int(self.request.get('number_in_stock'))
		product.manufacturer_key=manufacturer_key	
		product.put()
		self.redirect("/product")

class AddProductsJson(webapp2.RequestHandler):
	def post(self):
		productJson = json.loads(self.request.body)
		#id=self.request.get['id']
		#urlsafe_entity_key = self.request.get('manufacture_entity_key')
		query_results = Product.query(Product.id==productJson["id"]).fetch()
		logging.info("XXXXX--------------XXXXXXXXXXX")
		logging.info(productJson["manufacturer_key"])
		manufacturer_key = ndb.Key(urlsafe=productJson["manufacturer_key"])
		if len(query_results) == 0:
			# Edit
			#manufacture_key = ndb.Key(urlsafe=urlsafe_entity_key)
			#manufacture = manufacture_key.get()

			product = Product()
		else:
		# Add
			product = query_results[0];

		product.id = productJson["id"]
		product.product_name = productJson["product_name"]
		product.unit_cost = float(productJson["unit_cost"])
		product.number_in_stock = int(productJson["number_in_stock"])
		product.manufacturer_key = manufacturer_key
			
		product.put()
		data = {}
		data['message'] = 'Updated Product (PUT):'+productJson["id"]
		json_response = json.dumps(data)
		self.response.headers['Content-Type'] = 'text/x-json'
		self.response.write(json_response)

class add_to_cartJson(webapp2.RequestHandler):
	def post(self):
		productJson = json.loads(self.request.body)
		usr= users.get_current_user()
		
		cartitem=Cart_Item()
		cartitem.product_id=productJson["product_id"]
		cartitem.quantity=int(productJson["quantity"])
		cartitem.unit_cost=float(productJson["unit_cost"])
		cartitem.total_cost=int(productJson["quantity"])*float(productJson["unit_cost"])
		cartitem.user_id=usr.user_id()
		cartitem.put()
		data = {}
		data['message'] = 'Added to cart (PUT)'
		json_response = json.dumps(data)
		self.response.headers['Content-Type'] = 'text/x-json'
		self.response.write(json_response)
		
class addToOrder(webapp2.RequestHandler):
	def post(self):
		user = users.get_current_user()
		#inserting Orders
		carts=utils.getCartForUser(user.user_id())
		if len(carts)>0:
			ord=utils.getNextOrderNo(user)
			
			if len(ord)==0:
				nextNo=1
			else:
				nextNo=ord[0].id + 1
			logging.info(nextNo)
			#Saving Order 
			order=Order()
			order.id=nextNo
			order.user_id=user.user_id()
			order.total_price=utils.getCartTotal(user)
			order.put()
			#Saving Order_item
			
			for c in carts:
				order_item=Order_Item()
				order_item.order_id=nextNo
				order_item.user_id=c.user_id
				order_item.product_id=c.product_id
				order_item.quantity=c.quantity
				order_item.unit_cost=c.unit_cost
				order_item.total_cost=c.total_cost
				order_item.put()
			#deleting cart
			for c in carts:
				c.key.delete()
			self.redirect("/order")
		else:
			self.redirect("/")
		