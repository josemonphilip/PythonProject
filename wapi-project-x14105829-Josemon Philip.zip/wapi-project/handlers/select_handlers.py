from google.appengine.api import users
from google.appengine.ext import ndb
from models import Manufacturer, Product
import utils
import json
import webapp2
import logging

class SelectManufactureJson(webapp2.RequestHandler):
	def get(self):
		manufactures, manufactures_map = utils.get_manufacturer()
		result={}
		result=[p.to_dict() for p in manufactures]
		self.response.headers['Content-Type']='text/x-json'
		self.response.write(json.dumps(result))
		
class SelectProductJson(webapp2.RequestHandler):
	def get(self):
		manufactures, manufactures_map = utils.get_manufacturer()
		products = utils.get_Product_entries(manufactures_map)
		result=[]
		for p in products:
			#store each publisher in a dictionary
			products = {}
			products['id'] = p.id
			products['product_name'] = p.product_name
			products['unit_cost'] = p.unit_cost
			products['number_in_stock'] = p.number_in_stock
			products['manufacturer'] = p.manufacturer.business_name
			#add the dictionary to the list
			result.append(products);
		#Create a new dictionary for the results
		r={};
		#Give the results dictionary a key called publishers whos value is the list of publishers returned
		r= result;
		self.response.headers['Content-Type']='text/x-json'
		self.response.write(json.dumps(r))
		
class SelectCartJson(webapp2.RequestHandler):
	def get(self):
		user = users.get_current_user()
		manufactures, manufactures_map = utils.get_manufacturer()
		carts=utils.getCartForUser(user.user_id())
		cartCount=len(carts)
		mycarts=[]
		totalCost=0.0;
		for crt in carts:
			prd=utils.get_Single_Product(crt.product_id,manufactures_map)
			cart = {}
			cart['key'] =crt.key.urlsafe()
			cart['product_name'] = prd[0].product_name
			cart['unit_cost'] = crt.unit_cost
			cart['quantity'] = crt.quantity
			cart['total_cost'] = crt.total_cost
			cart['manufacturer'] = prd[0].manufacturer.business_name
			totalCost=totalCost + crt.total_cost
			mycarts.append(cart);
		r={};
		r['carts']= mycarts
		r['cartCount']=cartCount
		r['totalCost']=totalCost
		self.response.headers['Content-Type']='text/x-json'
		self.response.write(json.dumps(r))
		
class SelectOrderJson(webapp2.RequestHandler):
	def get(self):
		user = users.get_current_user()
		
		
		orders=utils.getOrderForUser(user)
		result={}
		result=[o.to_dict() for o in orders]
		self.response.headers['Content-Type']='text/x-json'
		self.response.write(json.dumps(result))
			
class SelectOrderItemJson(webapp2.RequestHandler):
	def get(self,id):
		user = users.get_current_user()
		manufactures, manufactures_map = utils.get_manufacturer()
		
		orderItems=utils.getOrderItemsForUser(user,int(id))
		logging.info("XXXXX--------------")
		logging.info(id)
		myOrder=[]
		for o in orderItems:
			prd=utils.get_Single_Product(o.product_id,manufactures_map)
			ord = {}
			ord['product_name'] = prd[0].product_name
			ord['unit_cost'] = o.unit_cost
			ord['quantity'] = o.quantity
			ord['total_cost'] = o.total_cost
			ord['manufacturer'] = prd[0].manufacturer.business_name
			myOrder.append(ord);
		r={};
		r['orders']= myOrder
		self.response.headers['Content-Type']='text/x-json'
		self.response.write(json.dumps(r))
		
		