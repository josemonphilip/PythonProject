from google.appengine.api import users
import main
import utils
import webapp2
import logging


class UserHandler(webapp2.RequestHandler):
	def get(self):
		user = users.get_current_user()
		#TODO also add cart details
		usr=utils.get_UserDetails(user)
		a=[]
		if len(usr)==0:
			b={}
			b['user_name']=None
			b['user_address']=None
			a.append(b)
			c={}
			c=a
		else:
			c=usr
			
		logging.info('------------------------------')
		#logging.info(len(r))
		
		template=main.JINJA_ENVIRONMENT.get_template('templates/userprofile.html')
		self.response.out.write(template.render({'users': c,
												'user_id':user.user_id(),
												'user_email': user.email(),
												'logout_url': users.create_logout_url("/"),
												'isadmin':users.is_current_user_admin()}))

class ShoppingCartPage(webapp2.RequestHandler):
	def get(self):
		
		user = users.get_current_user()
		manufactures, manufactures_map = utils.get_manufacturer()
		product_entries = utils.get_Product_entries(manufactures_map)
		#TODO also add cart details
		carts=utils.getCartForUser(user.user_id())
		cartCount=len(carts)
		mycarts=[]
		totalCost=0.0;
		for crt in carts:
			prd=utils.get_Single_Product(crt.product_id,manufactures_map)
			cart = {}
			cart['key'] =crt.key.urlsafe()
			cart['product_name'] = prd[0].product_name
			cart['unit_cost'] = crt.unit_cost
			cart['quantity'] = crt.quantity
			cart['total_cost'] = crt.total_cost
			cart['manufacturer'] = prd[0].manufacturer.business_name
			totalCost=totalCost + crt.total_cost
			mycarts.append(cart);
		r={};
		r= mycarts;
		
		template=main.JINJA_ENVIRONMENT.get_template('templates/index.html')
		self.response.out.write(template.render({'products': product_entries,
												'carts':r,
												'cartCount':cartCount,
												'cartTotal':totalCost,
												'user_email': user.email(),
												'logout_url': users.create_logout_url("/"),
												'isadmin':users.is_current_user_admin()}))
		

class ManufactureHandler(webapp2.RequestHandler):
	def get(self):
		user = users.get_current_user()
		manufactures, manufactures_map = utils.get_manufacturer()
		template=main.JINJA_ENVIRONMENT.get_template('templates/manufacturer.html')
		self.response.out.write(template.render({'manufactures': manufactures,
												'user_email': user.email(),
												'logout_url': users.create_logout_url("/"),
												'isadmin':users.is_current_user_admin()}))  
		

class ProductHandler(webapp2.RequestHandler):
	def get(self):
		user = users.get_current_user()
		manufactures, manufactures_map = utils.get_manufacturer()
		products=utils.get_Product_entries(manufactures_map)
		template=main.JINJA_ENVIRONMENT.get_template('templates/product.html')
		self.response.out.write(template.render({'manufactures': manufactures,
												'products':products,
												'user_email': user.email(),
												'logout_url': users.create_logout_url("/"),
												'isadmin':users.is_current_user_admin()}
												))  
	
	
class OrderHandler(webapp2.RequestHandler):
	def get(self):
		user = users.get_current_user()
		manufactures, manufactures_map = utils.get_manufacturer()
		
		orders=utils.getOrderForUser(user)
		
		template=main.JINJA_ENVIRONMENT.get_template('templates/orders.html')
		self.response.out.write(template.render({'user_email': user.email(),
												'orders':orders,
												'logout_url': users.create_logout_url("/"),
												'isadmin':users.is_current_user_admin()}
												))  