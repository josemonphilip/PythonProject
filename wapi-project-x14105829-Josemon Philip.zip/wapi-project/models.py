from google.appengine.ext import ndb

class User(ndb.Model):
	"""A main model for representing an individual User entry."""
	id= ndb.StringProperty(indexed=True)
	user_name = ndb.StringProperty(indexed=False)
	user_address = ndb.StringProperty(indexed=False)

class Manufacturer(ndb.Model):
	""" Manufacturer. """
	id= ndb.StringProperty(indexed=True)
	business_name  = ndb.StringProperty()
	email_address = ndb.StringProperty()
	url_address = ndb.StringProperty()
	phone_number = ndb.StringProperty()
	
class Product(ndb.Model):
	""" Product. """
	id= ndb.StringProperty(indexed=True)
	product_name = ndb.StringProperty()
	unit_cost = ndb.FloatProperty()
	number_in_stock = ndb.IntegerProperty(indexed=False)
	manufacturer_key = ndb.KeyProperty(kind=Manufacturer)

class Cart_Item(ndb.Model):
	id= ndb.StringProperty(indexed=True)
	user_id=ndb.StringProperty()
	product_id= ndb.StringProperty()
	quantity = ndb.IntegerProperty()
	unit_cost = ndb.FloatProperty()
	total_cost= ndb.FloatProperty()
	
class Order(ndb.Model):
	id= ndb.IntegerProperty(indexed=True)
	user_id=ndb.StringProperty()
	total_price= ndb.FloatProperty()
	
class Order_Item(ndb.Model):
	id= ndb.StringProperty(indexed=True)
	order_id =ndb.IntegerProperty()
	user_id=ndb.StringProperty()
	order=ndb.StructuredProperty(Order,repeated=True)
	product_id= ndb.StringProperty()
	quantity = ndb.IntegerProperty()
	unit_cost = ndb.FloatProperty()
	total_cost= ndb.FloatProperty()
