
$(function() {
	var  emailRegex = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
		id=$( "#id" ),
		business_name = $( "#business_name" ),
		email_address = $( "#email_address" ),
		url_address = $( "#url_address" ),
		phone_number = $( "#phone_number" ),
		allFields = $( [] ).add( business_name ).add( email_address ).add(id),
		tips = $( ".validateTips" );
	
    dialog = $( "#dialog-form" ).dialog({
      autoOpen: false,
      height: 430,
      width: 450,
      modal: true,
      buttons: {
        "Save": addUser,
        Cancel: function() {
          dialog.dialog( "close" );
        }
      },
      close: function() {
        form[ 0 ].reset();
        allFields.removeClass( "ui-state-error" );
	}})
	form = dialog.find( "form" ).on( "submit", function( event ) {
      event.preventDefault();
      addUser();
    });
	
		function updateTips( t ) {
			tips
			.text( t )
			.addClass( "ui-state-highlight" );
			setTimeout(function() {
			tips.removeClass( "ui-state-highlight", 1500 );
			}, 500 );
		}
		
		function checkLength( o, n, min, max ) {
			if ( o.val().length > max || o.val().length < min ) {
				o.addClass( "ui-state-error" );
				updateTips( "Length of " + n + " must be between " +
				min + " and " + max + "." );
				return false;
				} else {
					return true;
			}
		}

		function checkRegexp( o, regexp, n ) {
			if ( !( regexp.test( o.val() ) ) ) {
				o.addClass( "ui-state-error" );
				updateTips( n );
				return false;
			} else {
				return true;
			}
		}
		
	function addUser() {
		var valid = true;
		id=$( "#id" );
		business_name = $( "#business_name" );
		email_address = $( "#email_address" );
		url_address = $( "#url_address" );
		phone_number = $( "#phone_number" );
		allFields.removeClass( "ui-state-error" );
		valid = valid && checkLength( id, "ID", 3, 10 );
		valid = valid && checkLength( business_name, "business name", 3, 100 );
		//valid = valid && checkLength( email_address, "email_address", 6, 80 );
		//valid = valid && checkRegexp( name, /^[a-z]([0-9a-z_\s])+$/i, "Username may consist of a-z, 0-9, underscores, spaces and must begin with a letter." );
		valid = valid && checkRegexp( email_address, emailRegex, "eg. ui@jquery.com" );
		if ( valid ) {
			$.ajax({
				type: "post",
				url: '/manufacture/addJson',
				data: JSON.stringify({
				"id":id.val(),
				"business_name":business_name.val(),
				"email_address":email_address.val(),
				"url_address":url_address.val(),
				"phone_number":phone_number.val()
				}),
				dataType:"json",
				success: function(data,msg)
				{
					
					alert(data.message);
					listAll();

				},
				error: function ()
				{
					alert("");
				}
			});

		dialog.dialog( "close" );
		}
	}
	 
	 $( "#CreateManufact" ).click( function() {
		$("#id").prop("readonly",false);
		dialog.dialog( "open" );
	})
	
	
	//$(".edit-manufacturer").click(function() {
	$('table').on('click','.edit-manufacturer',function() {
		id=$(this).find(".id").html();
		business_name = $(this).find(".business_name").html();
		email_address = $(this).find(".email_address").html();
		url_address = $(this).find(".url_address").html();
		phone_number = $(this).find(".phone_number").html();
		//entity_key= $(this).find(".manufacture_entity_key").html();
		$("#dialog-form input[name=id]").val(id);
		$("#dialog-form input[name=business_name]").val(business_name);
		$("#dialog-form input[name=email_address]").val(email_address);
		$("#dialog-form input[name=url_address]").val(url_address);
		$("#dialog-form input[name=phone_number]").val(phone_number);
		//$("#dialog-form input[name=manufacture_entity_key]").val(entity_key);
		//$("#add-manufacturer-modal-title").html("Update Manufacture info");
		$("#id").prop("readonly",true);
		dialog.dialog( "open" );
	});
	
	//DElete
	confirDialog=$( "#dialog-confirm" ).dialog({
			  autoOpen: false,
			  resizable: false,
			  height:200,
			  width:500,
			  modal: true,
			  buttons: {
				"Delete item": function() {
					$( this ).dialog( "close" );
					$.ajax({
						type:'DELETE',
						url:'/manufacture/Delete/'+$("#delete-manufacture-name").text(),
						dataType:'json',
						success:function(data,msg){
							alert(data.message)
							listAll();
						}
						});
						},
					Cancel: function() {
					  $( this ).dialog( "close" );
					}
			  }
			});
	 $('table').on('click','.delete-manufacture',function() {
		name = $(this).find(".business_name").html();
		id = $(this).find(".id_delete").html();
		
		$("#delete-manufacture-name").html(id);
		confirDialog.dialog( "open" );
	})
	
	function listAll(){
		//$(".id_delete").text("");
		var table="<table class='table table-striped'>";
		var row="";
		
		table+="<thead><tr><th>ID</th><th>Business Name</th><th>email</th><th>URL</th><th>Phone</th><th>Actions</th></thead>"
		
		$.ajax({
			type:'GET',
			url:'list_manufactureJson',
			dataType:'json',
			success:function(data){
				$.each(data,function(index,element){
					row+="<tr>";
					row+="<td>"+element.id+"</td>" + "<td>"+element.business_name +"</td><td>"+element.email_address +"</td><td>"+element.url_address +"</td><td>"+element.phone_number +"</td>";
					row+="<td>";
					row+="<button   type='button' class='edit-manufacturer btn btn-xs btn-success'>Edit";
					row+="<div class='hidden id'>"+element.id+"</div>";
					row+="<div class='hidden business_name'>"+element.business_name+"</div>";
					row+="<div class='hidden email_address'>"+element.email_address+"</div>";
					row+="<div class='hidden url_address'>"+element.url_address+"</div>";
					row+="<div class='hidden phone_number'>"+element.phone_number+"</div>";
					row+="</button>";
					
					row+="<button  type='button' class='delete-manufacture btn btn-xs btn-danger'>Delete";
						row+="<div class='hidden id_delete'>"+element.id+"</div>";
						row+="<div class='hidden business_name'>"+element.business_name+"</div>";
						row+="<div class='hidden email_address'>"+element.email_address+"</div>";
					row+="</button>";
					row+="</td>";
					row+="</tr>";
					
					
				})
				
				table+=row;
				table+="</table>"
				$("table").html(table);
			}
		});
		
	}
})