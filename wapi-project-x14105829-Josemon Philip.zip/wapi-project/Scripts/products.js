$(function(){
	var  emailRegex = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
		id=$( "#id" ),
		product_name = $( "#product_name" ),
		unit_cost = $( "#unit_cost" ),
		number_in_stock = $( "#number_in_stock" ),
		manufacturer_key = $( "#manufacturer_key" ),
		allFields = $( [] ).add( product_name ).add( unit_cost ).add(id),
		tips = $( ".validateTips" );
	
    dialog = $( "#dialog-form" ).dialog({
      autoOpen: false,
      height: 450,
      width: 800,
      modal: true,
      buttons: {
        "Save": addProduct,
        Cancel: function() {
          dialog.dialog( "close" );
        }
      },
      close: function() {
        form[ 0 ].reset();
        allFields.removeClass( "ui-state-error" );
	}})
	form = dialog.find( "form" ).on( "submit", function( event ) {
      event.preventDefault();
      addUser();
    });
	function updateTips( t ) {
		tips
		.text( t )
		.addClass( "ui-state-highlight" );
		setTimeout(function() {
		tips.removeClass( "ui-state-highlight", 1500 );
		}, 500 );
	}
	function checkLength( o, n, min, max ) {
	if ( o.val().length > max || o.val().length < min ) {
		o.addClass( "ui-state-error" );
		updateTips( "Length of " + n + " must be between " +
		min + " and " + max + "." );
		return false;
		} else {
			return true;
		}
	}	
	
	function checkRegexp( o, regexp, n ) {
	if ( !( regexp.test( o.val() ) ) ) {
		o.addClass( "ui-state-error" );
		updateTips( n );
		return false;
	} else {
		return true;
		}
	}
	function addProduct() {
		var valid = true;
		id=$( "#id" );
		product_name = $( "#product_name" );
		unit_cost = $( "#unit_cost" );
		number_in_stock = $( "#number_in_stock" );
		manufacturer_key = $( "#manufacturer_key" );

		
		allFields.removeClass( "ui-state-error" );
		valid = valid && checkLength( id, "ID", 3, 10 );
		//valid = valid && checkLength( product_name, "product name", 3, 100 );
		//valid = valid && checkLength( email_address, "email_address", 6, 80 );
		//valid = valid && checkRegexp( name, /^[a-z]([0-9a-z_\s])+$/i, "Username may consist of a-z, 0-9, underscores, spaces and must begin with a letter." );
		
		if ( valid ) {
			$.ajax({
				type: "post",
				url: '/product/addJson',
				data: JSON.stringify({
				"id":id.val(),
				"product_name":product_name.val(),
				"unit_cost":unit_cost.val(),
				"number_in_stock":number_in_stock.val(),
				"manufacturer_key":manufacturer_key.val()
				}),
				dataType:"json",
				success: function(data,msg)
				{
					alert(data.message);
					listAll();
				},
				error: function ()
				{
					alert("");
				}
			});

		dialog.dialog( "close" );
		}
	}
	$( "#CreateProduct" ).click( function() {
		$("#id").prop("readonly",false);
		dialog.dialog( "open" );
	})
	
	$('table').on('click','.edit-product',function() {
		id=$(this).find(".id").html();
		product_name = $(this).find(".product_name").html();
		unit_cost = $(this).find(".unit_cost").html();
		number_in_stock = $(this).find(".number_in_stock").html();
		manufacturer_key = $(this).find(".manufacturer_key").html();
		//entity_key= $(this).find(".manufacture_entity_key").html();
		$("#dialog-form input[name=id]").val(id);
		$("#dialog-form input[name=product_name]").val(product_name);
		$("#dialog-form input[name=unit_cost]").val(unit_cost);
		$("#dialog-form input[name=number_in_stock]").val(number_in_stock);
		$("#dialog-form input[name=manufacturer_key]").val(manufacturer_key);
		//$("#dialog-form input[name=manufacture_entity_key]").val(entity_key);
		//$("#add-manufacturer-modal-title").html("Update Manufacture info");
		$("#id").prop("readonly",true);
		dialog.dialog( "open" );
	});
	
	//DElete
	confirDialog=$( "#dialog-confirm" ).dialog({
			  autoOpen: false,
			  resizable: false,
			  height:200,
			  width:500,
			  modal: true,
			  buttons: {
				"Delete item": function() {
					$( this ).dialog( "close" );
					$.ajax({
						type:'DELETE',
						url:'/product/delete/'+$("#delete-product-name").text(),
						dataType:'json',
						success:function(data,msg){
							alert(data.message)
							listAll();
						}
						});
						},
					Cancel: function() {
					  $( this ).dialog( "close" );
					}
		  }
	});
	
	 $('table').on('click','.delete-product',function() {
		name = $(this).find(".product_name").html();
		id = $(this).find(".id_delete").html();
		
		$("#delete-product-name").html(id);
		confirDialog.dialog( "open" );
	})
	
	function listAll(){
		//$(".id_delete").text("");
		var table="<table class='table table-striped'>";
		var row="";
		
		table+="<thead><tr><th>Product Name</th><th> manufacturer</th><th>Cost per Unit</th><th>Stock</th><th>Actions</th></thead>"
		
		$.ajax({
			type:'GET',
			url:'list_productJson',
			dataType:'json',
			success:function(data){
				$.each(data,function(index,element){
					row+="<tr>";
					row+="<td>"+element.product_name+"</td>" + "<td>"+element.manufacturer +"</td><td>"+element.unit_cost +"</td><td>"+element.number_in_stock +"</td>";
					row+="<td>";
					row+="<button   type='button' class='edit-product btn btn-xs btn-success'>Edit";
					row+="<div class='hidden id'>"+element.id+"</div>";
					row+="<div class='hidden product_name'>"+element.product_name+"</div>";
					row+="<div class='hidden business_name'>"+element.manufacturer+"</div>";
					row+="<div class='hidden unit_cost'>"+element.unit_cost+"</div>";
					row+="<div class='hidden number_in_stock'>"+element.number_in_stock+"</div>";
					row+="</button>";
					
					row+="<button  type='button' class='delete-product btn btn-xs btn-danger'>Delete";
						row+="<div class='hidden id_delete'>"+element.id+"</div>";
						row+="<div class='hidden product_name'>"+element.product_name+"</div>";
					row+="</button>";
					row+="</td>";
					row+="</tr>";
					
					
				})
				
				table+=row;
				table+="</table>"
				$("table").html(table);
			}
		});
		
	}
	
	
})