$(function() {
	refreshGrid();
	$('#Ordertable').on('click','.OrderDetails',function() {
		id=$(this).find(".id_details").html();
		$.ajax({
			type: "get",
			url: '/order/orderItems/'+id,
			success: function(data,msg)
			{
				var table="<table class='table table-striped'>";
				var row="";
				table+="<thead><tr><th>Product Name</th><th> manufacturer</th><th>Cost/Unit</th><th>Qty</th><th>tot.Cost</th></thead>"
				$.each(data.orders,function(index,element){
					row+="<tr>";
					row+="<td>"+element.product_name+"</td>" + "<td>"+element.manufacturer +"</td><td>"+element.unit_cost +"</td><td>"+element.quantity +"</td><td>"+element.total_cost +"</td>";
					row+="<td>";
				})
				table+=row;
				table+="</table>"
				$("#OrderTable").html(table);
			},
			error: function ()
			{
				alert("");
			}
		});
		
	})
	
	confirDialog=$( "#dialog-confirm" ).dialog({
		  autoOpen: false,
		  resizable: false,
		  height:200,
		  width:500,
		  modal: true,
		  buttons: {
			"Delete item": function() {
				$( this ).dialog( "close" );
				$.ajax({
					type:'DELETE',
					url:'order/delete/'+$("#delete-orderid").text(),
					dataType:'json',
					success:function(data,msg){
						alert(data.message)
						refreshGrid();
						$("#OrderTable").html("");
					}
					});
					},
				Cancel: function() {
				  $( this ).dialog( "close" );
				}
	  }
	});
	
	 $('#Ordertable').on('click','.delete-item',function() {
		id = $(this).find(".id_delete").html();
		$("#delete-orderid").html(id);
		confirDialog.dialog( "open" );
	})
	
	function refreshGrid(){
			var table="<table class='table table-striped'>";
		var row="";
		
		table+="<thead><tr><th>Order Id</th><th> Amount</th><th>Actions</th></thead>"
		
		$.ajax({
			type:'GET',
			url:'/order/listJson',
			dataType:'json',
			success:function(data){
				$.each(data,function(index,element){
					row+="<tr>";
					row+="<td>"+element.id+"</td>" + "<td>"+element.total_price +"</td>";
					row+="<td>";
					row+="<button   type='button' class='OrderDetails btn btn-xs btn-success'>Details";
					row+="<div class='hidden id_details'>"+element.id+"</div>";
					row+="</button>";
					row+="<button  type='button' class='delete-item btn btn-xs btn-danger'>Delete";
						row+="<div class='hidden id_delete'>"+element.id+"</div>";
					row+="</button>";
					row+="</td>";
					row+="</tr>";
					
					
				})
				
				table+=row;
				table+="</table>"
				$("#Ordertable").html(table);
			}
		});
	}
})