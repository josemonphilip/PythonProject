$(function() {
	  dialog = $( "#dialog-form" ).dialog({
		  autoOpen: false,
		  height: 330,
		  width: 550,
		  modal: true,
		  buttons: {
			"Save": addtoCart,
			Cancel: function() {
			  dialog.dialog( "close" );
			}
		  },
		  close: function() {
			
			//allFields.removeClass( "ui-state-error" );
		}})

		
		function checkStock( s, q ) {
			if ( q > s ) {
				o.addClass( "ui-state-error" );
				updateTips( "Quantity should less than  " + s);
				return false;
				} else {
					return true;
			}
		}
		
		
		$('table').on('click','.addtocart',function() {
			id=$(this).find(".id").html();
			product_name = $(this).find(".product_name").html();
			unit_cost = $(this).find(".unit_cost").html();
			
			//entity_key= $(this).find(".manufacture_entity_key").html();
			$("#id").text(id);
			$("#product_name").text(product_name);
			$("#unit_cost").text(unit_cost);
			//$("#dialog-form input[name=number_in_stock]").val(number_in_stock);

			dialog.dialog( "open" );
	});
	
	function addtoCart(){
		
		product_id = $( "#id" );
		quantity = $( "#quantity" );
		unit_cost = $( "#unit_cost" );
		$( this ).dialog( "close" );
		$.ajax({
			type: "post",
			url: '/cart/addJson',
			data: JSON.stringify({
				"product_id":product_id.text(),
				"quantity":quantity.val(),
				"unit_cost":parseFloat(unit_cost.text())
				
			}),
			dataType:"json",
			success: function(data,msg)
			{
				alert(data.message);
				refreshCart();

			},
			error: function ()
			{
				alert("");
			}
		});
	}
	
	function refreshCart(){
		//$(".id_delete").text("");
		
		var table="<table class='table table-striped'>";
		var row="";
		table+="<thead><tr><th>Product Name</th><th> manufacturer</th><th>Cost/Unit</th><th>Qty</th><th>tot.Cost</th><th>Actions</th></thead>"
		$.ajax({
			type:'GET',
			url:'/cart/list',
			dataType:'json',
			success:function(data,msg){
				$("#TotCartCnt").html(data.cartCount)
				$("#totAmt").text('Sub Total : '+data.totalCost)
				$.each(data.carts,function(index,element){
					row+="<tr>";
					row+="<td>"+element.product_name+"</td>" + "<td>"+element.manufacturer +"</td><td>"+element.unit_cost +"</td><td>"+element.quantity +"</td><td>"+element.total_cost +"</td>";
					row+="<td>";
					row+="<button  type='button' class='delete-item btn btn-xs btn-danger'>Remove";
						row+="<div class='hidden id_delete'>"+element.key+"</div>";
						row+="<div class='hidden product_name'>"+element.product_name+"</div>";
					row+="</button>";
					row+="</td>";
					row+="</tr>";
				})
				table+=row;
				table+="</table>"
				$("#CartTable").html(table);
			}
		});
	
	}
	
	confirDialog=$( "#dialog-confirm" ).dialog({
			  autoOpen: false,
			  resizable: false,
			  height:200,
			  width:500,
			  modal: true,
			  buttons: {
				"Delete item": function() {
					$( this ).dialog( "close" );
					$.ajax({
						type:'DELETE',
						url:'/cart/delete/'+$("#itemkey").text(),
						dataType:'json',
						success:function(data,msg){
							alert(data.message)
							refreshCart();
						}
						});
						},
					Cancel: function() {
					  $( this ).dialog( "close" );
					}
		  }
	});
	
	 $('#CartTable').on('click','.delete-item',function() {
		name = $(this).find(".product_name").html();
		id = $(this).find(".id_delete").html();
		$("#itemkey").html(id);
		$("#delete-product-name").html(name);
		confirDialog.dialog( "open" );
	})
	
})