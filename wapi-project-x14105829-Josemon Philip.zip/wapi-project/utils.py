from google.appengine.ext import ndb
from models import Manufacturer, Product,User,Cart_Item,Order,Order_Item

def get_parent_key(user):
  return ndb.Key("Entity", user.email().lower())


def get_UserDetails(userid):
	user=User.query(User.id==userid.user_id()).fetch(1)
	return user
	
def get_manufacturer():

	manufacturers = Manufacturer.query().order(Manufacturer.id).fetch()
	manufacturers_map = {}
	for manufacturer in manufacturers:
		manufacturers_map[manufacturer.key] = manufacturer
	return manufacturers, manufacturers_map

	
def get_Product_entries(manufacturers_map):

	product_entries = Product.query().fetch()
	for product_entry in product_entries:
		product_entry.manufacturer = manufacturers_map[product_entry.manufacturer_key]
	return product_entries

def get_Single_Product(productid,manufacturers_map):

	product_entries = Product.query(Product.id==productid).fetch(1)
	for product_entry in product_entries:
		product_entry.manufacturer = manufacturers_map[product_entry.manufacturer_key]
	return product_entries
	
def getCartForUser(userid):
	cart=Cart_Item.query(Cart_Item.user_id==userid).fetch()
	return cart
	
def getNextOrderNo(user):
	order=Order.query(Order.user_id==user.user_id()).order(-Order.id).fetch(1)
	return order

def getCartTotal(user):
	carts=Cart_Item.query(Cart_Item.user_id==user.user_id()).fetch()
	total=0.0
	for c in carts:
		total=total + c.total_cost
	return total
def getOrderForUser(user):
	order=Order.query(Order.user_id==user.user_id()).fetch()
	return order

def getOrderItemsForUser(user,id):
	orderItem=Order_Item.query(ndb.AND(Order_Item.user_id==user.user_id(),Order_Item.order_id==id)).fetch()
	return orderItem

